package com.uas.service;
import java.sql.SQLException;
import java.util.ArrayList;

import com.uas.bean.ParticipantBean;
import com.uas.bean.UniversityBean;
import com.uas.dao.IUniversityDAO;
import com.uas.dao.UniversityDAOImpl;

public class UniversityServiceImpl implements IUniversityService {

	IUniversityDAO uda=null;
	@Override
	public int addProgramScheduledDetails(UniversityBean ub) throws SQLException {
		uda=new UniversityDAOImpl();

	    int sid= 0;
	
		sid = uda.addProgramScheduledDetails(ub);
	
	    return sid;
		
	}
	@Override
	public UniversityBean getProgramDetailsById(int pid) throws SQLException {
		uda=new UniversityDAOImpl();

		return uda.getProgramDetailsById(pid);
		
	}
	@Override
	public ArrayList<UniversityBean> getDetails() throws SQLException {
		uda = new UniversityDAOImpl();
		return uda.getDetails();
	}
	@Override
	public void deleteProgram(int did) throws SQLException {
		uda = new UniversityDAOImpl();
		 uda.deleteProgram(did);
		
	}
	@Override
	public ArrayList<ParticipantBean> getParticipantDetails() throws SQLException {
		uda = new UniversityDAOImpl();
		return uda.getParticipantDetails();
	}

}
