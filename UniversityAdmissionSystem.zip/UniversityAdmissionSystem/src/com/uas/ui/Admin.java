package com.uas.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.uas.bean.ParticipantBean;
import com.uas.bean.UniversityBean;
import com.uas.service.IUniversityService;
import com.uas.service.UniversityServiceImpl;

public class Admin {
	 static Scanner scn = new Scanner(System.in);
	 static IUniversityService ser = null;
	public static void main(String[] args) throws SQLException {
		
		int i=0;
	do{
		i++;
	
		System.out.println("--------------UNIVERSITY ADMISSION SYSTEM------------------");
		System.out.println("1.PROGRAM OFFERED TABLE ");
		System.out.println("2.PROGRAM SCHEDULED TABLE ");
		System.out.println("3.VIEW PARTICIPANT LIST");
		System.out.println("4.Exit");
		int choice1=scn.nextInt();
	switch(choice1)
	{
	case 1:
					System.out.println("--------------PROGRAM OFFERED TABLE------------------");
					System.out.println("1.ADD PROGRAM ");
			   	    System.out.println("2.RETRIVE PROGRAM BY SCHEDULED ID");
			   	    System.out.println("3.VIEW ALL SCHEDULED PROGRAMS");
			   	    System.out.println("4.UPDATE SCHEDULED PROGRAM BY SCHEDULED ID");
			   	    System.out.println("5.DELETE PROGRAM BY SCHEDULED ID");
			   	    System.out.println("6.EXIT ");
					break;
	case 2:
					System.out.println("--------------PROGRAM SCHEDULED TABLE------------------");
					System.out.println("1.ADD PROGRAM ");
			   	    System.out.println("2.RETRIVE PROGRAM BY SCHEDULED ID");
			   	    System.out.println("3.VIEW ALL SCHEDULED PROGRAMS");
			   	    System.out.println("4.UPDATE SCHEDULED PROGRAM BY SCHEDULED ID");
			   	    System.out.println("5.DELETE PROGRAM BY SCHEDULED ID");
			   	    System.out.println("6.EXIT ");
			        int choice = scn.nextInt();
			        switch(choice){
			        
			        
	        
	        
		        	case 1:
		       	    System.out.println("Enter Your Program Name");
		       	    String pname = scn.next();
		       	    System.out.println("Enter Location");
		       	   String location = scn.next();
		       	   System.out.println("Enter Start Date");
		       	   String date1 = scn.next();
		       	   System.out.println("Enter End Date");
		    	   String date2 = scn.next();
		       	   System.out.println("Enter No of Sessions Per week");
		       	   int sessions = scn.nextInt();
		       	   UniversityBean ub = new UniversityBean();
		       	   
		       	   ub.setProgramName(pname);
		       	   ub.setLocation(location);
		       	   ub.setStartDate(date1);
		       	   ub.setEndDate(date2);
		       	   ub.setSessionsPerWeek(sessions);
		       	   
		       	   int sid=0;
		  	   
					 sid = addProgramScheduledDetails(ub);
				
					 System.out.println("Program Information stored successfully for program Scheduled  id:"+sid);
					 break;
		        	case 2:
	        	
		        	 System.out.println("Enter Program Scheduled id");
		        	 int pid = scn.nextInt();
		        	
		        	 ub = new UniversityBean();
		        	 ub = getProgramDetailsById(pid);
		        	 System.out.println(ub);
	        	
		        	 break;
		        	case 3:
	        	
		        	ArrayList<UniversityBean> List=getDetails();
		        	
		    		for(UniversityBean e:List)
		    			{
		    			System.out.println(e);
		    			}
		        	break;
		        	case 4:
		        		break;
		        	case 5:
		        	System.out.println("enter the id");
					int did = scn.nextInt();
					deleteProgram(did);
		        	break;
		        	case 6:
		        		 System.exit(0);
		        		 break;
		        	default:
		        		 System.out.println("Invalid case");
		        			 
		        	}
			        break;
	case 3:
			
			
				ArrayList<ParticipantBean> pList=getParticipantDetails();
	        	
	    		for(ParticipantBean e:pList)
	    			{
	    			System.out.println(e);
	    			}
	    		break;
		
	case 4:
				System.exit(0);
				break;
	default:
		 System.out.println("Invalid case");
			
		}
	
	}while(i<=3);
	}
      
	private static ArrayList<ParticipantBean> getParticipantDetails() throws SQLException {
		ser = new UniversityServiceImpl();
		return ser.getParticipantDetails();
	}
	private static void deleteProgram(int did) throws SQLException {
		ser = new UniversityServiceImpl();
		ser.deleteProgram(did);
		
	}
	private static ArrayList<UniversityBean> getDetails() throws SQLException {
		ser = new UniversityServiceImpl();
		return ser.getDetails();
	}
	private static int addProgramScheduledDetails(UniversityBean ub) throws SQLException {
		ser = new UniversityServiceImpl();
		return ser.addProgramScheduledDetails(ub);
		
	}
	
	private static UniversityBean getProgramDetailsById(int pid) throws SQLException {
		ser = new UniversityServiceImpl();
		return ser.getProgramDetailsById(pid);
	}

	}
